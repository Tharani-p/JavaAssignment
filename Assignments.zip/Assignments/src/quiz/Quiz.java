package quiz;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Quiz {
	
	String question;
	String option,answer,enter;
	int answered = 0;
	
	Quiz[] questions =new Quiz[3];
		
	public void numberOfQuestions() {
		for(int i=0; i<3; i++) {
			questions[i] = new Quiz();
		}
	}

		public void quizAnswers() {
	        try {
	        	questions[0].question="Can we have two public classes in one java file? ";
	        	questions[1].question="Which arithmetic operations can result in the throwing of an ArithmeticException? ";
	            questions[2].question="What is an Interface?";
	        }
	        catch(ArrayIndexOutOfBoundsException e) {
	        	e.printStackTrace();
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
			
		public void quizOptions()
		{
	        try {
	        	questions[0].option=" A. True \n B. False";
	        	questions[1].option=" A./ , % \n B. * , + \n C. ! , - \n D. >>, <<";
	        	questions[2].option="A. An interface is a collection of abstract methods. \n B.Interface is an abstract class.\n C.Interface is an concrete class.\n D.None";
	        }
	        catch(ArrayIndexOutOfBoundsException e) {
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		
		
		public void answers(){
			questions[0].answer="B";
			questions[1].answer="A";
			questions[2].answer="C";
	        		
		}
		public void executeQuiz(){
			char c;
			
	        try{
	            Scanner scan = new Scanner(System.in);
	            String temp="";

	            for(int i=0; i<3; i++)
	            {
	                System.out.println("Question "+(i+1)+": "+questions[i].question+"\n"+questions[i].option );
	                System.out.printf("Enter Your Answer:"+"\n");
	                
	                temp=scan.next();
	                c=temp.charAt(0);
	                temp=Character.toString(c);
	                
	                if(temp.equalsIgnoreCase(questions[i].answer))
	                {
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is CORRECT");
	                    answered++;
	                }
	                else
	                {
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is INCORRECT");
	                    System.out.println("Correct Answer is: "+questions[i].answer );
	                }
	            }
	        }
	        
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	            System.err.println("Error Occur3c!\n"+e.getMessage());
	            System.exit(0);
	        }
	        catch(InputMismatchException e)
	        {
	            System.err.println("Error Occur1!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		
		public void validation()
		{
	        System.out.println("Result : \n"+answered+" Correct and "+ (3-answered) +" Incorrect");
		}

	public static void main(String[] args) 
	{
		System.out.println("Name:Medidi Satyam");
		Quiz Object = new Quiz();
		Object.numberOfQuestions();
		Object.quizAnswers();
		Object.quizOptions();
		Object.answers();
		Object.executeQuiz();
		Object.validation();   
	}
}

