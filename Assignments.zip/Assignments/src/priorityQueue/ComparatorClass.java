package priorityQueue;

import java.util.Comparator;

public class ComparatorClass implements Comparator<Employee> {
  
 @Override
 public int compare(Employee x, Employee y) {
	 
		  return y.getName().compareTo(x.getName());
	}
}


