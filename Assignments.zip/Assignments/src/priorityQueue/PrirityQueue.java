package priorityQueue;

import java.util.PriorityQueue;

public class PrirityQueue {
	public static void main(String[] args) {
		
		PriorityQueue<Employee> employees = new PriorityQueue<Employee>(10, new ComparatorClass());
		 employees.add(new Employee("Priya",10032));
		 employees.add(new Employee("Vidhusha", 45345));
		 employees.add(new Employee("Bala", 23123));
		 employees.add(new Employee("Akshaya", 4354534));
		 System.out.println("Employee List in decreasing order based on the name :");

		 for (Employee emp : employees) {
			System.out.println(emp.getName() + " " + emp.getSalary());
		}
		
		}

}
