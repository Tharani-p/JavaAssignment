package synonyms;

import java.util.HashMap;
import java.util.Scanner;

public class Synonyms_Assignment {

	public static void main(String[] args) {
		
		HashMap<String,String[]> worldList = new HashMap<String,String[]>();
		
		worldList.put("signal", new String[]{"instruction","order"});
		worldList.put("promise",new String[]{"assurance","guarantee"});
		worldList.put("script", new String[]{"text"});
		
		System.out.println("Enter the word to find out alternate meaning: " );
		
		Scanner scanner = new Scanner(System.in);
		String key = scanner.next();
		scanner.nextLine();
		
		if (worldList.containsKey(key)) {
			String[] words = worldList.get(key);
			System.out.println("Synonyms List : ");
			
			for (String word : words) {
				System.out.println(word);
			}
		} else {
			System.out.println("word not found. Please enter correct text.");
		}
	}
}
