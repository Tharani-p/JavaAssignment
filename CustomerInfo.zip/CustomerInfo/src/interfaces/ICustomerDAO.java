package interfaces;


import beans.Customer;

public interface ICustomerDAO {
	
		public boolean insert(Customer cust);

		public boolean delete(int custId);
		
		public Customer getCustomerInfo(int custId);
}
